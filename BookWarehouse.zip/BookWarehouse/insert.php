    <!DOCTYPE HTML>
    <html>

    <head>
        <title>ADD BOOK</title>

        <!-- Latest compiled and minified Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />

    </head>

    <body>
    <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">BookWarehouse</a>
      </div>
      <ul class="nav navbar-nav">
        <li ><a href="index.php">Home</a></li>
        <li><a href="insert.php">Add Book</a></li>
        <li><a href="category.php">Category</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>

    </div>
  </nav>

        <?php
        $databaseHost = 'localhost';
        $databaseName = 'bookwarehouse';
        $databaseUsername = 'root';
        $databasePassword = '';

        $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

        $query1 = "SELECT category_name FROM category";
        $result2 = mysqli_query($mysqli, $query1);

        $options = "";

        while ($row2 = mysqli_fetch_array($result2)) {
            $options = $options . "<option>$row2[0]</option>";
        }
        ?>

        <!-- container -->
        <div class="container">

            <div class="page-header">
                <h1>ADD BOOK</h1>
            </div>

            <!-- html form to create product will be here -->

        </div> <!-- end .container -->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

        <!-- Latest compiled and minified Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    </body>

    </html>
    <?php
    if ($_POST) {

        // include database connection
        include 'database.php';

        try {

            // insert query
            $query = "INSERT INTO books SET title=:title, author=:author, price=:price, year=:year, image=:image ,medium=:medium, ISBN=:ISBN, category_id=:category_name";

            // prepare query for execution
            $stmt = $con->prepare($query);

            // posted values
            $title = htmlspecialchars(strip_tags($_POST['title']));
            $author = htmlspecialchars(strip_tags($_POST['author']));
            $price = htmlspecialchars(strip_tags($_POST['price']));
            $year = htmlspecialchars(strip_tags($_POST['year']));
            $medium = htmlspecialchars(strip_tags($_POST['medium']));
            $ISBN = htmlspecialchars(strip_tags($_POST['ISBN']));
            $image = htmlspecialchars(strip_tags($_POST['image']));
            $category_name = htmlspecialchars(strip_tags($_POST['category_name']));




            // bind the parameters
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':author', $author);
            $stmt->bindParam(':year', $year);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':medium', $medium);
            $stmt->bindParam(':ISBN', $ISBN);
            $stmt->bindParam(':image', $image);
            $stmt->bindParam(':category_name', $category_name);









            // Execute the query
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>Record was saved.</div>";
            } else {
                echo "<div class='alert alert-danger'>Unable to save record.</div>";
            }
        }

        // show error
        catch (PDOException $exception) {
            die('ERROR: ' . $exception->getMessage());
        }
    }
    ?>

    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <table class='table table-hover table-responsive table-bordered'>
            <tr>
                <td>Title</td>
                <td><input type='text' name='title' class='form-control' /></td>
            </tr>
            <tr>
                <td>Author</td>
                <td><textarea name='author' class='form-control'></textarea></td>
            </tr>
            <tr>
                <td>Price</td>
                <td><input type='text' name='price' class='form-control' /></td>
            </tr>
            <tr>
                <td>Year</td>
                <td><input type='text' name='year' class='form-control' /></td>
            </tr>
            <tr>
                <td>Medium</td>
                <td><input type='text' name='medium' class='form-control' /></td>
            </tr>
            <tr>
                <td>ISBN</td>
                <td><input type='text' name='ISBN' class='form-control' /></td>
            </tr>
            <tr>
                <td>Image</td>
                <td><input type='file' name='image' class='form-control' /></td>
            </tr>
            <tr>
                <td>Category Name</td>
                <td><select name='category_name' class='form-control'>
                        <?php echo $options; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type='submit' value='Save' class='btn btn-primary' />
                    <a href='index.php' class='btn btn-danger'>Back to read products</a>
                </td>
            </tr>
        </table>
    </form>