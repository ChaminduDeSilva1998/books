<?php
session_start();

if (!isset($_SESSION['name'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  ?>
<html>

<head>
  <title>User Login</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
</head>


<?php
$databaseHost = 'localhost';
$databaseName = '141202';
$databaseUsername = '141202';
$databasePassword = 'chamindu12345';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

$query1 = "SELECT category_name FROM category";
$result2 = mysqli_query($mysqli, $query1);

$options = "";

while ($row2 = mysqli_fetch_array($result2)) {
    $options = $options . "<option>$row2[0]</option>";
}
?>

<body>


  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">BookWarehouse</a>
      </div>
      <ul class="nav navbar-nav">
        <li ><a href="index.php">Home</a></li>
        <li><a href="insert.php">Add Book</a></li>
        <li><a href="category.php">Category</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>

    </div>
  </nav>
  <form action="category.php" method="GET">
        <div class="custom-select" style="width:200px;">
            <select name='category_name' class='form-control'>
                <?php echo $options; ?>
            </select>
            <br>
            <button type="submit" class="btn btn-success">Submit</button>
        </div>
    </form>



  <!--search-->
  <form action="search.php" method="GET">
    <input type="text" name="search" />
    <button type="submit" value="Search" class="btn btn-success">Search Books</Button>
  </form>




  <table class="table table-bordered">
    <thead class="thead-dark">
      <tr>
        <th scope="col">Book Title</th>
        <th scope="col">Book Author</th>
        <th scope="col">Book Price</th>
        <th scope="col">Book Image</th>
        <th scope="col">Action</th>

      </tr>
    </thead>



    <?php
    $conn = mysqli_connect("localhost", "141202", "chamindu12345", "141202");
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM books";
    $result = $conn->query($sql);
    while ($row = mysqli_fetch_array($result)) {
      $s = $row['image'];

      //delete popup
      $action = isset($_GET['action']) ? $_GET['action'] : "";

      // if it was redirected from delete.php
      if ($action == 'deleted') {
        echo "<div class='alert alert-success'>Record was deleted.</div>";
      }

    ?>



      <tr>
        <td><?php echo $row["title"]; ?></td>
        <td><?php echo $row["author"]; ?></td>
        <td style="width:100px"><?php echo $row["price"]; ?></td>
        <td><img src="images/<?php echo $row["image"]; ?>" class="block-20" style="width:170px;height:120px;"></td>
        <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-primary  view_data" />
          <?php echo "<a class='btn btn-warning' href=\"update.php?id=$row[id]\">Update</a> " ?>
          <?php echo "<a class='btn btn-danger' href=\"delete.php?id=$row[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a>  " ?>
      </tr>
    <?php
    }
    ?>
  </table>



</body>

<!--delete records-->
<script type='text/javascript'>
  // confirm record deletion
  function delete_book(id) {

    var answer = confirm('Are you sure?');
    if (answer) {
      // if user clicked ok, 
      // pass the id to delete.php and execute the delete query
      window.location = 'delete.php?id=' + id;
    }
  }
</script>


</html>
<div id="dataModal" class="modal fade">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Book Details</h4>
      </div>
      <div class="modal-body" id="book_detail">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script>
  $(document).ready(function() {
    $('.view_data').click(function() {
      var id = $(this).attr("id");
      $.ajax({
        url: "select.php",
        method: "post",
        data: {
          id: id
        },
        success: function(data) {
          $('#book_detail').html(data);
          $('#dataModal').modal("show");
        }
      });
    });
  });
</script>